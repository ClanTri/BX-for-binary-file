module Main where
{-# LANGUAGE FlexibleContexts, TemplateHaskell, TypeFamilies #-}
import Generics.BiGUL
import Generics.BiGUL.Interpreter
import Generics.BiGUL.TH
import Generics.BiGUL.Lib

sourceList :: [Source]
sourceList = [(1, "Alice"), (2, "Bob"), (3, "Charlie")]

viewList :: [View]
viewList = [(1, "Alice"), (3, "Charlie")]
delta :: Delta
delta = [(0, 0), (2, 1)]

main :: IO ()
main = do
    let updatedViewList = [(1, "Alice"), (3, "Charlie")]
    let updatedSource = putDeltaAlign bx cr sourceList delta updatedViewList
    print updatedSource  --